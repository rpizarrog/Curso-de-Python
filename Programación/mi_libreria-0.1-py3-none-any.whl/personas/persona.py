# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 09:34:50 2024

@author: rpizarro
"""

# personas.py

class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    def saludar(self):
        return f"Hola, mi nombre es {self.nombre} y tengo {self.edad} años."

    def cumpleanos(self):
        self.edad += 1
        return f"¡Feliz cumpleaños {self.nombre}! Ahora tienes {self.edad} años."
