# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 09:43:22 2024

@author: rpizarro
"""

# Mi Librería

Esta es una librería de ejemplo para demostrar cómo crear e instalar paquetes en Python.
