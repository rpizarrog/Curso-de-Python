# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 09:38:38 2024

@author: rpizarro
"""

from setuptools import setup, find_packages

setup(
    name='mi_libreria',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    description='Una librería simple de ejemplo.',
    author='RUBEN PIZARRO GURROLA',
    author_email='rpizarro@itdurango.edu.mx',
)
